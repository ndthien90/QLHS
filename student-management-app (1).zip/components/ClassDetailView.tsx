
import React, { useState } from 'react';
import { ClassData } from '../types';
import { EditIcon } from './icons';
import { formatCurrency } from '../utils/helpers';
import AddStudentPanel from './class-detail/AddStudentPanel';
import AttendancePanel from './class-detail/AttendancePanel';
import StatisticsPanel from './class-detail/StatisticsPanel';
import Modal from './Modal';


interface EditClassInfoModalProps {
    classData: ClassData;
    onSave: (name: string, fee: number) => void;
    onClose: () => void;
}

const EditClassInfoModal: React.FC<EditClassInfoModalProps> = ({ classData, onSave, onClose }) => {
    const [name, setName] = useState(classData.name);
    const [fee, setFee] = useState(classData.tuitionFee.toString());

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const tuitionFee = parseFloat(fee);
        if (name && tuitionFee >= 0) {
            onSave(name, tuitionFee);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <h2 className="text-2xl font-semibold mb-6">Sửa Thông Tin Lớp</h2>
            <div className="mb-4">
                <label htmlFor="class-name-edit" className="block text-sm font-medium text-gray-700 mb-2">Tên Lớp</label>
                <input 
                    type="text" 
                    id="class-name-edit" 
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" 
                    required 
                />
            </div>
            <div className="mb-6">
                <label htmlFor="class-fee-edit" className="block text-sm font-medium text-gray-700 mb-2">Học Phí (VNĐ / buổi)</label>
                <input 
                    type="number" 
                    id="class-fee-edit"
                    value={fee}
                    onChange={(e) => setFee(e.target.value)} 
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" 
                    min="0" 
                    step="1000" 
                    required 
                />
            </div>
            <div className="flex justify-end gap-4">
                <button type="button" onClick={onClose} className="py-2 px-5 rounded-lg bg-gray-200 text-gray-700 hover:bg-gray-300">Hủy</button>
                <button type="submit" className="py-2 px-5 rounded-lg bg-blue-500 text-white hover:bg-blue-600">Lưu Thay Đổi</button>
            </div>
        </form>
    );
};


interface ClassDetailViewProps {
    classData: ClassData;
    onSave: (classObject: ClassData) => void;
    getCollectionRef: any; // Simplified for this context
}

const ClassDetailView: React.FC<ClassDetailViewProps> = ({ classData, onSave, getCollectionRef }) => {
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);

    const handleSaveClassInfo = (newName: string, newFee: number) => {
        const updatedClass = { ...classData, name: newName, tuitionFee: newFee };
        onSave(updatedClass);
        setIsEditModalOpen(false);
    };

    return (
        <div>
            <div className="mb-8 p-4 sm:p-6 bg-white rounded-lg shadow-md">
                <div className="flex flex-wrap justify-between items-center gap-4">
                    <div>
                        <h2 id="class-detail-name" className="text-3xl font-bold text-gray-800">{classData.name}</h2>
                        <p id="class-detail-fee" className="text-lg text-gray-600 mt-2">
                            Học phí: <strong>{formatCurrency(classData.tuitionFee)} / buổi</strong>
                        </p>
                    </div>
                    <button onClick={() => setIsEditModalOpen(true)} id="edit-class-info-btn" className="bg-yellow-500 text-white font-semibold py-2 px-5 rounded-lg shadow-md hover:bg-yellow-600 transition-colors flex items-center flex-shrink-0">
                         <EditIcon />
                    </button>
                </div>
                <p id="class-detail-count" className="text-lg text-gray-600 mt-4">
                    Sĩ số: <strong>{classData.students?.length || 0} học sinh</strong>
                </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="flex flex-col gap-4">
                    <AddStudentPanel classData={classData} onSave={onSave} />
                    <AttendancePanel classData={classData} onSave={onSave} />
                </div>
                
                <StatisticsPanel classData={classData} onSave={onSave} />
            </div>

            <Modal isOpen={isEditModalOpen} onClose={() => setIsEditModalOpen(false)}>
                <EditClassInfoModal 
                    classData={classData}
                    onSave={handleSaveClassInfo}
                    onClose={() => setIsEditModalOpen(false)}
                />
            </Modal>
        </div>
    );
};

export default ClassDetailView;
