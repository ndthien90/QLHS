
import React, { useEffect, useRef } from 'react';

interface ModalProps {
    isOpen: boolean;
    onClose: () => void;
    children: React.ReactNode;
    size?: 'lg' | 'xl';
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, children, size = 'lg' }) => {
    const modalContentRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const modalContent = modalContentRef.current;
        if (isOpen) {
            // Delay to allow the component to render before starting the transition
            setTimeout(() => {
                modalContent?.classList.remove('scale-95', 'opacity-0');
                modalContent?.classList.add('scale-100', 'opacity-100');
            }, 50);
        }
    }, [isOpen]);

    if (!isOpen) {
        return null;
    }

    const handleClose = () => {
        const modalContent = modalContentRef.current;
        modalContent?.classList.add('scale-95', 'opacity-0');
        modalContent?.classList.remove('scale-100', 'opacity-100');
        setTimeout(onClose, 300); // Wait for transition to finish
    };
    
    const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
        if (e.target === e.currentTarget) {
            handleClose();
        }
    };

    const sizeClass = size === 'xl' ? 'max-w-xl' : 'max-w-lg';

    return (
        <div 
            id="modal-backdrop" 
            className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center p-4 z-50 transition-opacity duration-300"
            onClick={handleBackdropClick}
        >
            <div 
                ref={modalContentRef}
                id="modal-content" 
                className={`bg-white p-6 rounded-xl shadow-2xl w-full ${sizeClass} transform transition-all duration-300 scale-95 opacity-0`}
            >
                {children}
            </div>
        </div>
    );
};

export default Modal;
