
import React, { useState, useEffect } from 'react';
import { ClassData } from '../types';
import { TrashIcon, UpArrowIcon, DownArrowIcon } from './icons';
import Modal from './Modal';

interface ClassCardProps {
    classData: ClassData;
    onView: (id: string) => void;
    onDelete: (id: string, name: string) => void;
    onMoveUp: () => void;
    onMoveDown: () => void;
    isFirst: boolean;
    isLast: boolean;
}

const ClassCard: React.FC<ClassCardProps> = ({ classData, onView, onDelete, onMoveUp, onMoveDown, isFirst, isLast }) => {
    const studentCount = classData.students?.length || 0;
    return (
        <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow border-l-4 border-blue-500 transform hover:-translate-y-1 flex flex-col">
            <div className="flex-grow">
                <h3 className="text-xl font-bold text-blue-700 truncate">{classData.name}</h3>
                <p className="text-gray-600 mt-1">Sĩ số: <strong>{studentCount} học sinh</strong></p>
            </div>
            <div className="mt-6 flex justify-between items-center">
                <button onClick={() => onView(classData.id)} className="text-sm font-medium text-blue-600 hover:text-blue-800">
                    Xem Chi Tiết
                </button>
                <div className="flex items-center gap-1">
                    <button onClick={onMoveUp} disabled={isFirst} className="p-2 rounded-full hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed">
                        <UpArrowIcon className="h-5 w-5 text-gray-600"/>
                    </button>
                    <button onClick={onMoveDown} disabled={isLast} className="p-2 rounded-full hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed">
                        <DownArrowIcon className="h-5 w-5 text-gray-600"/>
                    </button>
                    <button onClick={() => onDelete(classData.id, classData.name)} className="text-red-500 hover:text-red-700 p-2 rounded-full hover:bg-red-50">
                        <TrashIcon />
                    </button>
                </div>
            </div>
        </div>
    );
};

interface DashboardViewProps {
    classes: ClassData[];
    onViewClass: (id: string) => void;
    onDeleteClass: (id: string) => void;
    onSaveOrder: (orderedClasses: ClassData[]) => Promise<void>;
}

const DashboardView: React.FC<DashboardViewProps> = ({ classes, onViewClass, onDeleteClass, onSaveOrder }) => {
    const [deleteModal, setDeleteModal] = useState<{isOpen: boolean; id: string | null, name: string | null}>({isOpen: false, id: null, name: null});
    const [orderedClasses, setOrderedClasses] = useState<ClassData[]>([]);
    const [isOrderChanged, setIsOrderChanged] = useState(false);
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        const sorted = [...classes].sort((a, b) => (a.order ?? 999) - (b.order ?? 999));
        setOrderedClasses(sorted);
        setIsOrderChanged(false);
    }, [classes]);

    const handleDeleteRequest = (id: string, name: string) => {
        setDeleteModal({ isOpen: true, id, name });
    };

    const confirmDelete = () => {
        if(deleteModal.id) {
            onDeleteClass(deleteModal.id);
        }
        setDeleteModal({ isOpen: false, id: null, name: null });
    };

    const handleMove = (index: number, direction: 'up' | 'down') => {
        const newOrderedClasses = [...orderedClasses];
        const targetIndex = direction === 'up' ? index - 1 : index + 1;
        
        if (targetIndex < 0 || targetIndex >= newOrderedClasses.length) return;
        
        [newOrderedClasses[index], newOrderedClasses[targetIndex]] = [newOrderedClasses[targetIndex], newOrderedClasses[index]];
        
        setOrderedClasses(newOrderedClasses);
        setIsOrderChanged(true);
    };

    const handleCancelOrder = () => {
        const sorted = [...classes].sort((a, b) => (a.order ?? 999) - (b.order ?? 999));
        setOrderedClasses(sorted);
        setIsOrderChanged(false);
    };

    const handleSaveOrder = async () => {
        setIsSaving(true);
        await onSaveOrder(orderedClasses);
        setIsSaving(false);
        setIsOrderChanged(false);
    };
    
    return (
        <div>
             <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
                <h2 className="text-2xl font-semibold text-gray-700">Các Lớp Học Hiện Có</h2>
                {isOrderChanged && (
                    <div className="flex items-center gap-4 animate-fade-in">
                        <button onClick={handleCancelOrder} className="bg-gray-200 text-gray-800 font-semibold py-2 px-4 rounded-lg shadow-sm hover:bg-gray-300">
                            Hủy
                        </button>
                        <button onClick={handleSaveOrder} disabled={isSaving} className="bg-green-500 text-white font-semibold py-2 px-4 rounded-lg shadow-sm hover:bg-green-600 disabled:bg-green-300">
                            {isSaving ? 'Đang lưu...' : 'Lưu Thứ Tự'}
                        </button>
                    </div>
                )}
            </div>
            {orderedClasses.length > 0 ? (
                <div id="class-list" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {orderedClasses.map((cls, index) => (
                        <ClassCard 
                            key={cls.id} 
                            classData={cls} 
                            onView={onViewClass} 
                            onDelete={handleDeleteRequest} 
                            onMoveUp={() => handleMove(index, 'up')}
                            onMoveDown={() => handleMove(index, 'down')}
                            isFirst={index === 0}
                            isLast={index === orderedClasses.length - 1}
                        />
                    ))}
                </div>
            ) : (
                <p id="no-classes-msg" className="text-gray-500 text-center py-10 text-lg">
                    Chưa có lớp học nào. Hãy thêm lớp mới!
                </p>
            )}

            <Modal isOpen={deleteModal.isOpen} onClose={() => setDeleteModal({isOpen: false, id: null, name: null})}>
                <div>
                    <h3 className="text-xl font-semibold mb-4">Xác Nhận Xóa Lớp</h3>
                    <p className="text-gray-700">Bạn có chắc chắn muốn xóa lớp <strong>{deleteModal.name}</strong>? Mọi dữ liệu học sinh và điểm danh sẽ bị mất vĩnh viễn.</p>
                    <div className="flex justify-end gap-4 mt-8">
                        <button type="button" onClick={() => setDeleteModal({isOpen: false, id: null, name: null})} className="py-2 px-5 rounded-lg bg-gray-200 text-gray-700 hover:bg-gray-300">Hủy</button>
                        <button type="button" onClick={confirmDelete} className="py-2 px-5 rounded-lg bg-red-500 text-white hover:bg-red-600">Xóa Vĩnh Viễn</button>
                    </div>
                </div>
            </Modal>
        </div>
    );
};

export default DashboardView;