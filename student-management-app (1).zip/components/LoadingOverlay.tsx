
import React from 'react';

interface LoadingOverlayProps {
    message?: string;
}

const LoadingOverlay: React.FC<LoadingOverlayProps> = ({ message = 'Đang tải...' }) => {
    return (
        <div id="loading-overlay" className="fixed inset-0 bg-gray-100 flex flex-col justify-center items-center z-50 transition-opacity duration-300">
            <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-blue-500 mb-4"></div>
            <p className="text-blue-600 font-semibold">{message}</p>
        </div>
    );
};

export default LoadingOverlay;
