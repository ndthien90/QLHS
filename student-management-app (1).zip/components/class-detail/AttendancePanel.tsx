
import React, { useState, useEffect } from 'react';
import { ClassData, Student } from '../../types';
import { PenIcon, CheckIcon } from '../icons';

// Define StudentRow component inside or outside, but not inside the render method of parent
const StudentRow: React.FC<{
    student: Student;
    isChecked: boolean;
    onCheckChange: (studentId: string, isChecked: boolean) => void;
    onNameSave: (studentId: string, newName: string) => void;
}> = ({ student, isChecked, onCheckChange, onNameSave }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [name, setName] = useState(student.name);

    const handleSave = () => {
        const trimmedName = name.trim();
        if (trimmedName && trimmedName !== student.name) {
            onNameSave(student.id, trimmedName);
        } else {
            setName(student.name); // Revert if empty or unchanged
        }
        setIsEditing(false);
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            handleSave();
        } else if (e.key === 'Escape') {
            setName(student.name);
            setIsEditing(false);
        }
    };

    return (
        <div className="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
            <input 
                type="checkbox" 
                checked={isChecked}
                onChange={(e) => onCheckChange(student.id, e.target.checked)}
                className="h-5 w-5 text-blue-600 rounded border-gray-300 focus:ring-blue-500 flex-shrink-0"
            />
            <div className="flex-grow flex items-center ml-4">
                <input 
                    type="text" 
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    onBlur={handleSave}
                    onKeyDown={handleKeyDown}
                    disabled={!isEditing}
                    className={`w-full text-gray-700 font-medium border rounded-md py-1 transition-all duration-200 ${
                        isEditing 
                        ? 'bg-white border-gray-400 shadow-sm px-2' 
                        : 'bg-transparent border-transparent px-0'
                    }`}
                />
            </div>
            {!isEditing ? (
                <button onClick={() => setIsEditing(true)} className="p-2 text-gray-500 hover:text-blue-600 rounded-full flex-shrink-0 ml-2">
                    <PenIcon />
                </button>
            ) : (
                <button onClick={handleSave} className="p-2 text-gray-500 hover:text-green-600 rounded-full flex-shrink-0 ml-2">
                    <CheckIcon />
                </button>
            )}
        </div>
    );
};

interface AttendancePanelProps {
    classData: ClassData;
    onSave: (classObject: ClassData) => void;
}

const AttendancePanel: React.FC<AttendancePanelProps> = ({ classData, onSave }) => {
    const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
    const [attendance, setAttendance] = useState<Record<string, boolean>>({});
    const [saveStatus, setSaveStatus] = useState<'idle' | 'saving'>('idle');

    useEffect(() => {
        const initialAttendance: Record<string, boolean> = {};
        classData.students?.forEach(student => {
            initialAttendance[student.id] = student.attendance.includes(selectedDate);
        });
        setAttendance(initialAttendance);
    }, [selectedDate, classData.students]);

    const handleCheckChange = (studentId: string, isChecked: boolean) => {
        setAttendance(prev => ({ ...prev, [studentId]: isChecked }));
    };
    
    const handleNameSave = (studentId: string, newName: string) => {
        const updatedStudents = classData.students.map(s => 
            s.id === studentId ? { ...s, name: newName } : s
        );
        onSave({ ...classData, students: updatedStudents });
    };

    const handleSaveAttendance = () => {
        setSaveStatus('saving');
        const updatedStudents = classData.students.map(student => {
            const hasAttended = student.attendance.includes(selectedDate);
            const shouldAttend = attendance[student.id];
            
            if (shouldAttend && !hasAttended) {
                return { ...student, attendance: [...student.attendance, selectedDate] };
            }
            if (!shouldAttend && hasAttended) {
                return { ...student, attendance: student.attendance.filter(d => d !== selectedDate) };
            }
            return student;
        });
        onSave({ ...classData, students: updatedStudents });
        setTimeout(() => setSaveStatus('idle'), 2000);
    };

    const toggleAll = (isChecked: boolean) => {
        const newAttendance: Record<string, boolean> = {};
        Object.keys(attendance).forEach(id => {
            newAttendance[id] = isChecked;
        });
        setAttendance(newAttendance);
    };

    return (
        <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-4 text-gray-700">Điểm Danh Hàng Ngày</h3>
            <div className="flex flex-wrap gap-4 items-center mb-6">
                <label htmlFor="attendance-date" className="font-medium">Chọn ngày:</label>
                <input 
                    type="date" 
                    id="attendance-date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button 
                    onClick={handleSaveAttendance}
                    className={`font-semibold py-2 px-6 rounded-lg shadow-md transition-colors ${
                        saveStatus === 'saving' 
                        ? 'bg-green-500 hover:bg-green-600 text-white' 
                        : 'bg-indigo-500 hover:bg-indigo-600 text-white'
                    }`}
                >
                    {saveStatus === 'saving' ? 'Đã Lưu!' : 'Lưu Điểm Danh'}
                </button>
            </div>
            <div className="flex gap-4 mb-6">
                <button onClick={() => toggleAll(true)} className="flex-1 bg-green-500 text-white font-semibold py-2 px-4 rounded-lg shadow-sm hover:bg-green-600 transition-colors">Tất Cả</button>
                <button onClick={() => toggleAll(false)} className="flex-1 bg-yellow-500 text-white font-semibold py-2 px-4 rounded-lg shadow-sm hover:bg-yellow-600 transition-colors">Xóa Tất Cả</button>
            </div>
            <div className="max-h-80 overflow-y-auto space-y-3 pr-2">
                {classData.students?.length > 0 ? (
                    classData.students.map(student => (
                        <StudentRow 
                            key={student.id}
                            student={student}
                            isChecked={!!attendance[student.id]}
                            onCheckChange={handleCheckChange}
                            onNameSave={handleNameSave}
                        />
                    ))
                ) : (
                    <p className="text-gray-500 text-center">Chưa có học sinh nào.</p>
                )}
            </div>
        </div>
    );
};

export default AttendancePanel;
