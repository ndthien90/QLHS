
import React, { useMemo, useState } from 'react';
import { ClassData, ClosingHistoryRecord, Student } from '../../types';
import { formatCurrency } from '../../utils/helpers';
import { HistoryIcon, PrintIcon } from '../icons';
import Modal from '../Modal';

interface BillingStatsProps {
    classData: ClassData;
    onSave: (classObject: ClassData) => void;
    startDate: string;
    endDate: string;
}

const BillingStats: React.FC<BillingStatsProps> = ({ classData, onSave, startDate, endDate }) => {
    const [modal, setModal] = useState<
        { type: null } |
        { type: 'confirmDelete', student: Student } |
        { type: 'massUpdate', status: 'paid' | 'unpaid' } |
        { type: 'viewHistory' } |
        { type: 'exportBill', student: Student }
    >({ type: null });

    const getFilteredAttendance = (student: Student) => {
        return student.attendance.filter(date => {
            const isAfterStart = !startDate || date >= startDate;
            const isBeforeEnd = !endDate || date <= endDate;
            return isAfterStart && isBeforeEnd;
        });
    };
    
    const { students, totalSessions, grandTotalTuition } = useMemo(() => {
        let totalSessions = 0;
        let grandTotalTuition = 0;
        const sortedStudents = [...(classData.students || [])].sort((a, b) => {
            const statusA = a.paymentStatus === 'paid' ? 1 : 0;
            const statusB = b.paymentStatus === 'paid' ? 1 : 0;
            return statusA - statusB;
        });

        const studentsWithStats = sortedStudents.map(student => {
            const filteredAttendance = getFilteredAttendance(student);
            const sessionCount = filteredAttendance.length;
            const studentTotalTuition = sessionCount * classData.tuitionFee;
            totalSessions += sessionCount;
            grandTotalTuition += studentTotalTuition;
            return { ...student, sessionCount, studentTotalTuition };
        });

        return { students: studentsWithStats, totalSessions, grandTotalTuition };
    }, [classData, startDate, endDate]);

    const handleTogglePayment = (studentId: string) => {
        const updatedStudents = classData.students.map(s =>
            s.id === studentId ? { ...s, paymentStatus: s.paymentStatus === 'paid' ? 'unpaid' : 'paid' } : s
        );
        onSave({ ...classData, students: updatedStudents });
    };

    const handleDeleteStudent = () => {
        if (modal.type === 'confirmDelete' && modal.student) {
            const updatedStudents = classData.students.filter(s => s.id !== modal.student.id);
            onSave({ ...classData, students: updatedStudents });
        }
        setModal({ type: null });
    };

    const confirmMassUpdate = () => {
        if (modal.type !== 'massUpdate') return;
        
        let updatedClass = { ...classData };

        if (modal.status === 'paid') {
            if (!startDate || !endDate) {
                alert("Vui lòng chọn cả Ngày Bắt Đầu và Ngày Kết Thúc.");
                setModal({ type: null });
                return;
            }
            let totalSessionsClosed = 0;
            let totalTuitionClosed = 0;
            
            updatedClass.students.forEach(student => {
                if (student.paymentStatus === 'paid') {
                    const filtered = getFilteredAttendance(student);
                    totalSessionsClosed += filtered.length;
                    totalTuitionClosed += filtered.length * classData.tuitionFee;
                }
            });

            if (totalSessionsClosed > 0) {
                const historyRecord: ClosingHistoryRecord = {
                    id: crypto.randomUUID(),
                    startDate, endDate, totalSessions: totalSessionsClosed, totalTuition: totalTuitionClosed,
                    closedAt: new Date().toISOString()
                };
                updatedClass.closingHistory = [...(updatedClass.closingHistory || []), historyRecord];
            }
        }
        
        const newStudents = updatedClass.students.map(student => {
            if (modal.status === 'paid') {
                if (student.paymentStatus === 'paid') {
                    const remainingAttendance = student.attendance.filter(date => date < startDate || date > endDate);
                    return { ...student, attendance: remainingAttendance, paymentStatus: 'unpaid' };
                }
            } else {
                 return { ...student, paymentStatus: 'unpaid' };
            }
            return student;
        });

        onSave({ ...updatedClass, students: newStudents as Student[]});
        setModal({ type: null });
    };

    const handlePrintBill = (contentId: string) => {
        const billContent = document.getElementById(contentId);
        if (!billContent) return;
        const printWindow = window.open('', '', 'height=600,width=800');
        printWindow?.document.write('<html><head><title>Hóa Đơn</title><style>body{font-family: sans-serif; padding: 20px;} h2{text-align: center;} .print-grid{display: grid; grid-template-columns: repeat(4, 1fr); gap: 5px; background: #f0f0f0; padding: 10px; border-radius: 5px;} .print-grid li{list-style: none; background: #e2e8f0; padding: 4px; text-align: center; border-radius: 3px;}</style></head><body>');
        printWindow?.document.write(billContent.innerHTML);
        printWindow?.document.write('</body></html>');
        printWindow?.document.close();
        printWindow?.focus();
        printWindow?.print();
        printWindow?.close();
    };

    const renderModals = () => {
        switch (modal.type) {
            case 'confirmDelete':
                return (
                    <Modal isOpen={true} onClose={() => setModal({ type: null })}>
                        <h3 className="text-xl font-semibold mb-4">Xác Nhận Xóa Học Sinh</h3>
                        <p>Bạn có chắc muốn xóa <strong>{modal.student.name}</strong>? Toàn bộ dữ liệu sẽ bị mất.</p>
                        <div className="flex justify-end gap-4 mt-8">
                            <button onClick={() => setModal({ type: null })} className="py-2 px-5 rounded-lg bg-gray-200">Hủy</button>
                            <button onClick={handleDeleteStudent} className="py-2 px-5 rounded-lg bg-red-500 text-white">Xóa</button>
                        </div>
                    </Modal>
                );
            case 'massUpdate':
                const isClosing = modal.status === 'paid';
                return (
                    <Modal isOpen={true} onClose={() => setModal({ type: null })}>
                        <h3 className="text-xl font-semibold mb-4">Xác Nhận Hành Động</h3>
                        <p>Bạn có chắc chắn muốn {isClosing ? 'chốt sổ và xóa các buổi học đã thanh toán' : 'reset trạng thái về "Chưa Đóng"'} cho tất cả học sinh?</p>
                        {isClosing && <p className="text-red-600 font-bold mt-2">Cảnh báo: Hành động này không thể hoàn tác.</p>}
                        <div className="flex justify-end gap-4 mt-8">
                            <button onClick={() => setModal({ type: null })} className="py-2 px-5 rounded-lg bg-gray-200">Hủy</button>
                            <button onClick={confirmMassUpdate} className={`py-2 px-5 rounded-lg text-white ${isClosing ? 'bg-green-500' : 'bg-red-500'}`}>Xác Nhận</button>
                        </div>
                    </Modal>
                );
            case 'viewHistory':
                return (
                    <Modal isOpen={true} onClose={() => setModal({ type: null })} size="xl">
                        <h2 className="text-2xl font-semibold mb-6">Lịch Sử Chốt Sổ</h2>
                        <ul className="space-y-3 max-h-80 overflow-y-auto pr-2">
                            {(classData.closingHistory || []).length > 0 ? [...classData.closingHistory].reverse().map(rec => (
                                <li key={rec.id} className="p-4 bg-gray-100 rounded-lg">
                                    <p><strong>Kỳ:</strong> {new Date(rec.startDate).toLocaleDateString('vi-VN')} - {new Date(rec.endDate).toLocaleDateString('vi-VN')}</p>
                                    <p><strong>Tổng số buổi:</strong> {rec.totalSessions}</p>
                                    <p><strong>Tổng học phí:</strong> {formatCurrency(rec.totalTuition)}</p>
                                    <p className="text-sm text-gray-500">Chốt lúc: {new Date(rec.closedAt).toLocaleString('vi-VN')}</p>
                                </li>
                            )) : <p>Chưa có lịch sử chốt sổ.</p>}
                        </ul>
                        <div className="flex justify-end mt-8">
                            <button onClick={() => setModal({ type: null })} className="py-2 px-5 rounded-lg bg-gray-200">Đóng</button>
                        </div>
                    </Modal>
                );
            case 'exportBill':
                const filtered = getFilteredAttendance(modal.student);
                const total = filtered.length * classData.tuitionFee;
                return (
                     <Modal isOpen={true} onClose={() => setModal({ type: null })}>
                        <div id={`bill-${modal.student.id}`}>
                            <h2 className="text-3xl font-bold text-center mb-6 text-gray-800">HÓA ĐƠN HỌC PHÍ</h2>
                            <p className="text-center text-gray-600 text-lg mb-4"><i>(Từ {startDate} đến {endDate})</i></p>
                            <div className="space-y-2 text-lg">
                                <p><strong>Học sinh:</strong> {modal.student.name}</p>
                                <p><strong>Lớp học:</strong> {classData.name}</p>
                                <p><strong>Số buổi học:</strong> {filtered.length}</p>
                                {filtered.length > 0 && 
                                    <>
                                        <p className="font-medium mt-4 mb-2">Chi tiết các buổi học:</p>
                                        <ul className="print-grid max-h-40 overflow-y-auto">
                                            {filtered.map(d => <li key={d}>{new Date(d).toLocaleDateString('vi-VN')}</li>)}
                                        </ul>
                                    </>
                                }
                                <hr className="my-4"/>
                                <p className="text-2xl font-semibold"><strong>Tổng số tiền:</strong> {formatCurrency(total)}</p>
                            </div>
                        </div>
                        <div className="flex justify-end gap-4 mt-8">
                            <button onClick={() => setModal({ type: null })} className="py-2 px-5 rounded-lg bg-gray-200">Đóng</button>
                            <button onClick={() => handlePrintBill(`bill-${modal.student.id}`)} className="py-2 px-5 rounded-lg bg-blue-500 text-white">In Hóa Đơn</button>
                        </div>
                    </Modal>
                );
            default:
                return null;
        }
    };
    
    return (
        <div>
            {renderModals()}
            <div className="mb-4">
                <button onClick={() => setModal({type: 'viewHistory'})} className="w-full text-sm bg-gray-200 text-gray-700 font-semibold py-2 px-4 rounded-lg shadow-sm hover:bg-gray-300 transition-colors flex items-center justify-center gap-2">
                    <HistoryIcon /> Lịch Sử Chốt Sổ
                </button>
            </div>
            
            <div className="flex flex-wrap gap-4 mb-6">
                <button onClick={() => setModal({type: 'massUpdate', status: 'paid'})} className="flex-1 bg-green-500 text-white font-semibold py-2 px-4 rounded-lg shadow-sm hover:bg-green-600 transition-colors">Chốt Sổ</button>
                <button disabled className="flex-1 bg-blue-300 cursor-not-allowed text-white font-semibold py-2 px-4 rounded-lg shadow-sm flex items-center justify-center gap-2">
                    <PrintIcon /> Hóa đơn (Sắp có)
                </button>
            </div>

            {students.length === 0 ? <p className="text-gray-500 text-center py-6 text-md">Chưa có học sinh nào trong lớp này.</p> : (
                <>
                {/* Mobile View */}
                <div className="space-y-4 md:hidden">
                    {students.map(student => (
                         <div key={student.id} className={`border rounded-lg p-4 shadow-sm ${student.paymentStatus === 'paid' ? 'bg-green-50' : 'bg-white'}`}>
                            <div className="flex justify-between items-start gap-3">
                                <h4 className="font-bold text-lg text-gray-900">{student.name}</h4>
                                <strong className="text-gray-800 text-lg text-right flex-shrink-0">{formatCurrency(student.studentTotalTuition)}</strong>
                            </div>
                            <div className="flex justify-between items-center mt-3 text-sm">
                                <div>
                                    <span className="text-gray-500">Số buổi:</span>
                                    <strong className="text-gray-800 ml-1">{student.sessionCount}</strong>
                                </div>
                                <div>
                                    <span className="text-gray-500">Trạng thái:</span>
                                    <strong className={`${student.paymentStatus === 'paid' ? 'text-green-700' : 'text-red-700'} ml-1`}>{student.paymentStatus === 'paid' ? 'Đã Đóng' : 'Chưa Đóng'}</strong>
                                </div>
                            </div>
                            <div className="flex flex-wrap gap-2 mt-4 border-t pt-3">
                                <button onClick={() => handleTogglePayment(student.id)} className={`text-sm py-1 px-3 rounded-md ${student.paymentStatus === 'paid' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'} font-medium`}>
                                    {student.paymentStatus === 'paid' ? 'Chưa Đóng' : 'Đã Đóng'}
                                </button>
                                <button onClick={() => setModal({ type: 'exportBill', student })} className="text-sm py-1 px-3 rounded-md bg-blue-100 text-blue-700 font-medium">
                                    Xuất Bill
                                </button>
                                <button onClick={() => setModal({ type: 'confirmDelete', student })} className="text-sm py-1 px-3 rounded-md bg-gray-100 text-gray-700 font-medium">
                                    Xóa
                                </button>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Desktop View */}
                <div className="overflow-x-auto hidden md:block">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Học Sinh</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Số Buổi</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tổng Học Phí</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Trạng Thái</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Hành Động</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                           {students.map(student => (
                               <tr key={student.id} className={student.paymentStatus === 'paid' ? 'bg-green-50' : 'bg-white'}>
                                   <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{student.name}</td>
                                   <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">{student.sessionCount}</td>
                                   <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{formatCurrency(student.studentTotalTuition)}</td>
                                   <td className="px-6 py-4 whitespace-nowrap text-sm">
                                       <span className={`px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${student.paymentStatus === 'paid' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                           {student.paymentStatus === 'paid' ? 'Đã Đóng' : 'Chưa Đóng'}
                                       </span>
                                   </td>
                                   <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                                       <button onClick={() => handleTogglePayment(student.id)} className={student.paymentStatus === 'paid' ? 'text-red-600 hover:text-red-800' : 'text-green-600 hover:text-green-800'}>
                                           {student.paymentStatus === 'paid' ? 'Chưa Đóng' : 'Đã Đóng'}
                                       </button>
                                       <button onClick={() => setModal({ type: 'exportBill', student })} className="text-blue-600 hover:text-blue-800">Xuất Bill</button>
                                       <button onClick={() => setModal({ type: 'confirmDelete', student })} className="text-gray-500 hover:text-red-600">Xóa</button>
                                   </td>
                               </tr>
                           ))}
                        </tbody>
                        <tfoot className="bg-gray-100 font-semibold">
                            <tr>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800">TỔNG CỘNG</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800 text-center">{totalSessions}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800">{formatCurrency(grandTotalTuition)}</td>
                                <td className="px-6 py-4" colSpan={2}></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                {/* Mobile Footer */}
                <div className="md:hidden mt-6 pt-4 border-t border-gray-200 font-semibold space-y-2">
                    <div className="flex justify-between items-center text-sm">
                        <span className="text-gray-600">Tổng số buổi:</span>
                        <span className="text-gray-900">{totalSessions}</span>
                    </div>
                    <div className="flex justify-between items-center text-base">
                        <span className="text-gray-600">Tổng học phí:</span>
                        <span className="text-gray-900">{formatCurrency(grandTotalTuition)}</span>
                    </div>
                </div>
                </>
            )}
        </div>
    );
};

export default BillingStats;
