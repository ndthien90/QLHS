
/**
 * Formats a number into Vietnamese Dong (VND) currency string.
 * @param amount - The number to format.
 * @returns A string representing the amount in VND.
 */
export function formatCurrency(amount: number): string {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
}
