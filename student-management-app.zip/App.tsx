
import React, { useState, useEffect, useCallback } from 'react';
import { initializeApp } from "firebase/app";
import { 
    getAuth, 
    onAuthStateChanged, 
    User,
    signOut
} from "firebase/auth";
import { 
    getFirestore, 
    collection, 
    doc, 
    onSnapshot, 
    query,
    setDoc,
    deleteDoc,
    Firestore
} from "firebase/firestore";

import { ClassData } from './types';
import LoginView from './components/LoginView';
import DashboardView from './components/DashboardView';
import ClassDetailView from './components/ClassDetailView';
import LoadingOverlay from './components/LoadingOverlay';
import Header from './components/Header';

// --- FIREBASE CONFIGURATION ---
// This mimics the logic from the original script to allow dynamic configuration.
let firebaseConfig;
let appId = 'default-app-id'; // Fallback App ID

try {
    // @ts-ignore
    if (typeof __firebase_config !== 'undefined') {
        // @ts-ignore
        firebaseConfig = JSON.parse(__firebase_config);
    } else {
        // Fallback config if not provided globally
        firebaseConfig = {
            apiKey: "AIzaSyCjk2GSw5sVSsnhSnu0zeCdM7Fy06na92o",
            authDomain: "qlhsapp.firebaseapp.com",
            projectId: "qlhsapp",
            storageBucket: "qlhsapp.firebasestorage.app",
            messagingSenderId: "267919381815",
            appId: "1:267919381815:web:6b0f469e6492a9c87636b2",
            measurementId: "G-ZZPSRHR0Z7"
        };
    }
    // @ts-ignore
    appId = typeof __app_id !== 'undefined' ? __app_id : appId;
} catch (e) {
    console.error("Firebase config error:", e);
    firebaseConfig = {};
}

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const App: React.FC = () => {
    const [user, setUser] = useState<User | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [view, setView] = useState<'login' | 'dashboard' | 'class_detail'>('login');
    
    const [classes, setClasses] = useState<ClassData[]>([]);
    const [currentClassId, setCurrentClassId] = useState<string | null>(null);

    const getCollectionRef = useCallback((userId: string) => {
        return collection(db, 'artifacts', appId, 'users', userId, 'classes');
    }, []);

    const saveClass = async (classObject: ClassData) => {
        if (!user) return;
        try {
            const classRef = doc(getCollectionRef(user.uid), classObject.id);
            await setDoc(classRef, classObject);
        } catch (error) {
            console.error("Error saving class:", error);
            alert("Lỗi khi lưu lớp học. Vui lòng thử lại.");
        }
    };

    const deleteClassFromFirestore = async (classId: string) => {
        if (!user) return;
        try {
            await deleteDoc(doc(getCollectionRef(user.uid), classId));
        } catch (error) {
            console.error("Error deleting class:", error);
            alert("Lỗi khi xóa lớp học. Vui lòng thử lại.");
        }
    };
    
    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
            setUser(firebaseUser);
            setIsLoading(false);
            if (!firebaseUser) {
                setView('login');
                setClasses([]);
                setCurrentClassId(null);
            } else {
                setView('dashboard');
            }
        });
        return () => unsubscribe();
    }, []);

    useEffect(() => {
        let unsubscribeFromFirestore: (() => void) | null = null;
        if (user) {
            const q = query(getCollectionRef(user.uid));
            unsubscribeFromFirestore = onSnapshot(q, (snapshot) => {
                const newClasses = snapshot.docs.map(doc => doc.data() as ClassData);
                setClasses(newClasses);

                // If the currently viewed class is deleted by another client, go back to dashboard
                if (currentClassId && !newClasses.some(c => c.id === currentClassId)) {
                    setCurrentClassId(null);
                    setView('dashboard');
                }
            }, (error) => {
                console.error("Firestore snapshot error:", error);
                alert("Lỗi kết nối dữ liệu. Vui lòng kiểm tra kết nối mạng.");
            });
        }
        
        // Cleanup function
        return () => {
            if (unsubscribeFromFirestore) {
                unsubscribeFromFirestore();
            }
        };
    }, [user, currentClassId, getCollectionRef]);


    const handleLogout = () => {
        signOut(auth).catch(error => console.error("Logout error:", error));
    };

    const handleViewClass = (classId: string) => {
        setCurrentClassId(classId);
        setView('class_detail');
    };

    const handleBackToDashboard = () => {
        setCurrentClassId(null);
        setView('dashboard');
    };
    
    const currentClass = classes.find(c => c.id === currentClassId);

    const renderContent = () => {
        if (isLoading) {
            return <LoadingOverlay message="Đang tải dữ liệu..." />;
        }
        if (!user) {
            return <LoginView auth={auth} db={db} appId={appId} />;
        }
        
        return (
            <div id="app-container" className="container mx-auto p-4 md:p-8 max-w-7xl">
                <Header 
                    view={view} 
                    onBack={handleBackToDashboard}
                    onLogout={handleLogout}
                    userEmail={user.email || ''}
                    classes={classes}
                    getCollectionRef={() => getCollectionRef(user.uid)}
                />
                <main id="app-content">
                    {view === 'dashboard' && (
                        <DashboardView 
                            classes={classes} 
                            onViewClass={handleViewClass} 
                            onDeleteClass={deleteClassFromFirestore}
                        />
                    )}
                    {view === 'class_detail' && currentClass && (
                        <ClassDetailView 
                            classData={currentClass} 
                            onSave={saveClass}
                            getCollectionRef={() => getCollectionRef(user.uid)}
                        />
                    )}
                </main>
            </div>
        );
    };

    return <>{renderContent()}</>;
};

export default App;
