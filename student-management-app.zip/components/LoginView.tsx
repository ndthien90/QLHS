
import React, { useState } from 'react';
import { Auth, signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc, Firestore } from 'firebase/firestore';

interface LoginViewProps {
    auth: Auth;
    db: Firestore;
    appId: string;
}

const LoginView: React.FC<LoginViewProps> = ({ auth, db, appId }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [errorMsg, setErrorMsg] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleAuthAction = async (action: 'login' | 'register') => {
        if (!email || !password) {
            setErrorMsg("Vui lòng nhập Email và Mật khẩu.");
            return;
        }
        if (action === 'register' && password.length < 6) {
            setErrorMsg("Mật khẩu phải có ít nhất 6 ký tự.");
            return;
        }

        setIsLoading(true);
        setErrorMsg('');

        try {
            if (action === 'login') {
                await signInWithEmailAndPassword(auth, email, password);
            } else {
                const userCredential = await createUserWithEmailAndPassword(auth, email, password);
                // Optionally create an initial document for the new user
                const userDocRef = doc(db, 'artifacts', appId, 'users', userCredential.user.uid);
                await setDoc(userDocRef, { createdAt: new Date().toISOString() });
            }
        } catch (error: any) {
            let message = "Có lỗi xảy ra. Vui lòng thử lại.";
            switch (error.code) {
                case 'auth/user-not-found':
                case 'auth/wrong-password':
                case 'auth/invalid-credential':
                    message = "Email hoặc mật khẩu không đúng.";
                    break;
                case 'auth/invalid-email':
                    message = "Email không hợp lệ.";
                    break;
                case 'auth/email-already-in-use':
                    message = "Email này đã được sử dụng.";
                    break;
                case 'auth/weak-password':
                    message = "Mật khẩu quá yếu (tối thiểu 6 ký tự).";
                    break;
                default:
                    console.error("Firebase Auth Error:", error);
            }
            setErrorMsg(message);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="flex items-center justify-center min-h-screen p-4">
             {isLoading && (
                <div className="fixed inset-0 bg-gray-100 bg-opacity-75 flex justify-center items-center z-50">
                    <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-blue-500"></div>
                </div>
            )}
            <div className="w-full max-w-md bg-white p-8 rounded-xl shadow-2xl">
                <h2 className="text-3xl font-bold text-center text-blue-600 mb-8">Quản Lý Học Sinh</h2>
                <form onSubmit={(e) => { e.preventDefault(); handleAuthAction('login'); }}>
                    <div className="mb-4">
                        <label htmlFor="login-email" className="block text-sm font-medium text-gray-700 mb-2">Email (Tên đăng nhập)</label>
                        <input 
                            type="email" 
                            id="login-email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" 
                            required 
                        />
                    </div>
                    <div className="mb-6">
                        <label htmlFor="login-password" className="block text-sm font-medium text-gray-700 mb-2">Mật khẩu</label>
                        <input 
                            type="password" 
                            id="login-password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" 
                            required 
                        />
                    </div>
                    <button type="submit" className="w-full bg-blue-500 text-white font-semibold py-3 px-6 rounded-lg shadow-md hover:bg-blue-600 transition-colors">Đăng Nhập</button>
                    <button type="button" onClick={() => handleAuthAction('register')} className="w-full mt-3 bg-gray-500 text-white font-semibold py-3 px-6 rounded-lg shadow-md hover:bg-gray-600 transition-colors">Đăng Ký Tài Khoản Mới</button>
                    {errorMsg && <p className="text-red-500 text-sm text-center mt-4">{errorMsg}</p>}
                    <p className="text-xs text-gray-500 text-center mt-4">Sử dụng Email và Mật khẩu để lưu trữ dữ liệu cá nhân của bạn trên Firebase.</p>
                </form>
            </div>
        </div>
    );
};

export default LoginView;
