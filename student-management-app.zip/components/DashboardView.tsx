
import React, { useState } from 'react';
import { ClassData } from '../types';
import { TrashIcon } from './icons';
import Modal from './Modal';

interface ClassCardProps {
    classData: ClassData;
    onView: (id: string) => void;
    onDelete: (id: string, name: string) => void;
}

const ClassCard: React.FC<ClassCardProps> = ({ classData, onView, onDelete }) => {
    const studentCount = classData.students?.length || 0;
    return (
        <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow border-l-4 border-blue-500 transform hover:-translate-y-1">
            <h3 className="text-xl font-bold text-blue-700 truncate">{classData.name}</h3>
            <p className="text-gray-600 mt-1">Sĩ số: <strong>{studentCount} học sinh</strong></p>
            <div className="mt-6 flex justify-between items-center">
                <button onClick={() => onView(classData.id)} className="text-sm font-medium text-blue-600 hover:text-blue-800">
                    Xem Chi Tiết
                </button>
                <button onClick={() => onDelete(classData.id, classData.name)} className="text-sm font-medium text-red-500 hover:text-red-700 p-2 rounded-full hover:bg-red-50">
                    <TrashIcon />
                </button>
            </div>
        </div>
    );
};

interface DashboardViewProps {
    classes: ClassData[];
    onViewClass: (id: string) => void;
    onDeleteClass: (id: string) => void;
}

const DashboardView: React.FC<DashboardViewProps> = ({ classes, onViewClass, onDeleteClass }) => {
    const [deleteModal, setDeleteModal] = useState<{isOpen: boolean; id: string | null, name: string | null}>({isOpen: false, id: null, name: null});

    const handleDeleteRequest = (id: string, name: string) => {
        setDeleteModal({ isOpen: true, id, name });
    };

    const confirmDelete = () => {
        if(deleteModal.id) {
            onDeleteClass(deleteModal.id);
        }
        setDeleteModal({ isOpen: false, id: null, name: null });
    };
    
    return (
        <div>
            <h2 className="text-2xl font-semibold mb-6 text-gray-700">Các Lớp Học Hiện Có</h2>
            {classes.length > 0 ? (
                <div id="class-list" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {classes.map(cls => (
                        <ClassCard key={cls.id} classData={cls} onView={onViewClass} onDelete={handleDeleteRequest} />
                    ))}
                </div>
            ) : (
                <p id="no-classes-msg" className="text-gray-500 text-center py-10 text-lg">
                    Chưa có lớp học nào. Hãy thêm lớp mới!
                </p>
            )}

            <Modal isOpen={deleteModal.isOpen} onClose={() => setDeleteModal({isOpen: false, id: null, name: null})}>
                <div>
                    <h3 className="text-xl font-semibold mb-4">Xác Nhận Xóa Lớp</h3>
                    <p className="text-gray-700">Bạn có chắc chắn muốn xóa lớp <strong>{deleteModal.name}</strong>? Mọi dữ liệu học sinh và điểm danh sẽ bị mất vĩnh viễn.</p>
                    <div className="flex justify-end gap-4 mt-8">
                        <button type="button" onClick={() => setDeleteModal({isOpen: false, id: null, name: null})} className="py-2 px-5 rounded-lg bg-gray-200 text-gray-700 hover:bg-gray-300">Hủy</button>
                        <button type="button" onClick={confirmDelete} className="py-2 px-5 rounded-lg bg-red-500 text-white hover:bg-red-600">Xóa Vĩnh Viễn</button>
                    </div>
                </div>
            </Modal>
        </div>
    );
};

export default DashboardView;
