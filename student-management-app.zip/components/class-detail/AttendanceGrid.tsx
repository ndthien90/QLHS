
import React, { useMemo } from 'react';
import { ClassData } from '../../types';
import { PrintIcon } from '../icons';

interface AttendanceGridProps {
    classData: ClassData;
    startDate: string;
    endDate: string;
}

const AttendanceGrid: React.FC<AttendanceGridProps> = ({ classData, startDate, endDate }) => {

    const { sortedDates, students } = useMemo(() => {
        const studentList = classData.students || [];
        const allDates = new Set<string>();
        studentList.forEach(student => {
            student.attendance.forEach(date => {
                const isAfterStart = !startDate || date >= startDate;
                const isBeforeEnd = !endDate || date <= endDate;
                if (isAfterStart && isBeforeEnd) {
                    allDates.add(date);
                }
            });
        });
        const sorted = Array.from(allDates).sort();
        return { sortedDates: sorted, students: studentList };
    }, [classData, startDate, endDate]);

    const handlePrint = () => {
        const printWindow = window.open('', '', 'height=800,width=1000');
        if (!printWindow) return;
        
        let headerHtml = '<thead><tr><th>Học Sinh</th>';
        sortedDates.forEach(date => {
            const d = new Date(date);
            const formattedDate = `${d.getDate().toString().padStart(2, '0')}/${(d.getMonth() + 1).toString().padStart(2, '0')}`;
            headerHtml += `<th>${formattedDate}</th>`;
        });
        headerHtml += '</tr></thead>';

        let bodyHtml = '<tbody>';
        students.forEach(student => {
            bodyHtml += `<tr><td>${student.name}</td>`;
            sortedDates.forEach(date => {
                const hasAttended = student.attendance.includes(date);
                bodyHtml += `<td>${hasAttended ? '✔' : '✖'}</td>`;
            });
            bodyHtml += '</tr>';
        });
        bodyHtml += '</tbody>';

        printWindow.document.write(`
            <html><head><title>Bảng Điểm Danh - ${classData.name}</title>
            <style>
                body { font-family: 'Inter', sans-serif; padding: 20px; }
                h1, h2 { text-align: center; }
                table { border-collapse: collapse; width: 100%; margin-top: 20px; font-size: 12px; }
                th, td { border: 1px solid #ccc; padding: 4px; text-align: center; }
                th { background-color: #f4f4f4; }
                td:first-child, th:first-child { text-align: left; }
            </style>
            </head><body>
            <h1>Bảng Điểm Danh: ${classData.name}</h1>
            <h2>(Từ ${startDate} đến ${endDate})</h2>
            <table>${headerHtml}${bodyHtml}</table>
            </body></html>
        `);
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };

    if (students.length === 0 || sortedDates.length === 0) {
        return <p className="text-gray-500 text-center py-6 text-md">Không có dữ liệu điểm danh nào trong khoảng ngày đã chọn.</p>;
    }

    return (
        <div>
            <div className="mb-4">
                <button onClick={handlePrint} className="w-full bg-teal-500 text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:bg-teal-600 transition-colors flex items-center justify-center gap-2">
                    <PrintIcon /> In danh sách
                </button>
            </div>

            <div className="overflow-x-auto border border-gray-200 rounded-lg max-h-[600px]">
                <table className="min-w-full divide-y divide-gray-200 text-xs">
                    <thead className="bg-gray-50 sticky top-0 z-10">
                        <tr>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase sticky left-0 bg-gray-50 z-20">Học Sinh</th>
                            {sortedDates.map(date => {
                                const d = new Date(date);
                                const formattedDate = `${d.getDate().toString().padStart(2, '0')}/${(d.getMonth() + 1).toString().padStart(2, '0')}`;
                                return <th key={date} title={d.toLocaleDateString('vi-VN')} className="px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase min-w-[30px]">{formattedDate}</th>;
                            })}
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {students.map(student => (
                            <tr key={student.id}>
                                <td className="px-4 py-2 whitespace-nowrap text-sm font-medium text-gray-900 sticky left-0 bg-white z-10">{student.name}</td>
                                {sortedDates.map(date => {
                                    const hasAttended = student.attendance.includes(date);
                                    return (
                                        <td key={`${student.id}-${date}`} className="text-center">
                                            <div className={`w-5 h-5 mx-auto rounded ${hasAttended ? 'bg-green-400' : 'bg-red-300'}`} title={hasAttended ? 'Có mặt' : 'Vắng mặt'}></div>
                                        </td>
                                    );
                                })}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default AttendanceGrid;
