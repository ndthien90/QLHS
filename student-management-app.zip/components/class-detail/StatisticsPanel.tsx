
import React, { useState } from 'react';
import { ClassData } from '../../types';
import BillingStats from './BillingStats';
import AttendanceGrid from './AttendanceGrid';

interface StatisticsPanelProps {
    classData: ClassData;
    onSave: (classObject: ClassData) => void;
}

const StatisticsPanel: React.FC<StatisticsPanelProps> = ({ classData, onSave }) => {
    const [activeTab, setActiveTab] = useState<'billing' | 'attendance'>('billing');
    
    const today = new Date().toISOString().split('T')[0];
    const firstDayOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0];
    
    const [startDate, setStartDate] = useState(firstDayOfMonth);
    const [endDate, setEndDate] = useState(today);
    
    return (
        <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-4 text-gray-700">Thống Kê Lớp Học</h3>

            <div className="mb-4 flex border-b border-gray-200">
                <button 
                    onClick={() => setActiveTab('billing')}
                    className={`flex-1 py-2 px-4 text-center font-medium text-sm ${
                        activeTab === 'billing' 
                        ? 'text-blue-600 border-b-2 border-blue-600' 
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                >
                    Thanh Toán
                </button>
                <button 
                    onClick={() => setActiveTab('attendance')}
                    className={`flex-1 py-2 px-4 text-center font-medium text-sm ${
                        activeTab === 'attendance' 
                        ? 'text-blue-600 border-b-2 border-blue-600' 
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                >
                    Điểm Danh
                </button>
            </div>
            
            <div className="mb-4 grid grid-cols-2 gap-4">
                <div>
                    <label htmlFor="closing-date-start" className="block text-sm font-medium text-gray-700 mb-2">Ngày Bắt Đầu:</label>
                    <input 
                        type="date" 
                        id="closing-date-start"
                        value={startDate}
                        onChange={e => setStartDate(e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                </div>
                <div>
                    <label htmlFor="closing-date-end" className="block text-sm font-medium text-gray-700 mb-2">Ngày Kết Thúc:</label>
                    <input 
                        type="date" 
                        id="closing-date-end"
                        value={endDate}
                        onChange={e => setEndDate(e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                </div>
            </div>

            {activeTab === 'billing' ? (
                <BillingStats 
                    classData={classData} 
                    onSave={onSave} 
                    startDate={startDate} 
                    endDate={endDate}
                />
            ) : (
                <AttendanceGrid 
                    classData={classData} 
                    startDate={startDate} 
                    endDate={endDate}
                />
            )}
        </div>
    );
};

export default StatisticsPanel;
