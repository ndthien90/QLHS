
import React, { useState, useRef } from 'react';
import { ClassData, Student } from '../../types';
import { TxtFileIcon, ExportIcon } from '../icons';
import Modal from '../Modal';

interface AddStudentPanelProps {
    classData: ClassData;
    onSave: (classObject: ClassData) => void;
}

const AddStudentPanel: React.FC<AddStudentPanelProps> = ({ classData, onSave }) => {
    const [newStudentName, setNewStudentName] = useState('');
    const [modalInfo, setModalInfo] = useState<{isOpen: boolean, title: string, message: string}>({isOpen: false, title: '', message: ''});
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleAddStudent = (e: React.FormEvent) => {
        e.preventDefault();
        const trimmedName = newStudentName.trim();
        if (!trimmedName) return;

        const newStudent: Student = {
            id: crypto.randomUUID(),
            name: trimmedName,
            attendance: [],
            paymentStatus: 'unpaid'
        };
        const updatedClass = { ...classData, students: [...(classData.students || []), newStudent] };
        onSave(updatedClass);
        setNewStudentName('');
    };

    const handleExport = () => {
        if (!classData.students || classData.students.length === 0) {
            setModalInfo({ isOpen: true, title: "Lỗi", message: "Lớp này không có học sinh nào để xuất." });
            return;
        }
        const studentNames = classData.students.map(s => s.name).join('\n');
        const blob = new Blob([studentNames], { type: 'text/plain;charset=utf-8' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        const fileName = `danh_sach_lop_${classData.name.replace(/\s+/g, '_')}.txt`;
        link.download = fileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(link.href);
    };

    const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file || file.type !== 'text/plain') {
            setModalInfo({ isOpen: true, title: "Lỗi", message: "Vui lòng chọn một tệp .txt hợp lệ." });
            return;
        }
        const reader = new FileReader();
        reader.onload = (event) => {
            const content = event.target?.result as string;
            const names = content.split('\n').map(name => name.trim()).filter(Boolean);
            if (names.length === 0) {
                setModalInfo({ isOpen: true, title: "Lỗi", message: "Tệp .txt không có tên học sinh nào hợp lệ." });
                return;
            }
            const newStudents: Student[] = names.map(name => ({
                id: crypto.randomUUID(),
                name,
                attendance: [],
                paymentStatus: 'unpaid'
            }));
            const updatedClass = { ...classData, students: [...(classData.students || []), ...newStudents] };
            onSave(updatedClass);
            setModalInfo({ isOpen: true, title: "Hoàn Tất", message: `Đã nhập thành công ${names.length} học sinh mới.` });
        };
        reader.onerror = () => {
            setModalInfo({ isOpen: true, title: "Lỗi", message: "Không thể đọc tệp. Vui lòng thử lại." });
        };
        reader.readAsText(file, 'UTF-8');
        e.target.value = ''; // Reset file input
    };

    return (
        <>
            <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-4 text-gray-700">Thêm Học Sinh Mới</h3>
                <form onSubmit={handleAddStudent} className="flex flex-col sm:flex-row gap-4">
                    <input 
                        type="text"
                        value={newStudentName}
                        onChange={(e) => setNewStudentName(e.target.value)} 
                        placeholder="Nhập tên học sinh..." 
                        className="flex-grow w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" 
                        required 
                    />
                    <button type="submit" className="bg-green-500 text-white font-semibold py-2 px-6 rounded-lg shadow-md hover:bg-green-600 transition-colors flex-shrink-0">Thêm</button>
                </form>
                
                <div className="mt-6 border-t pt-4 hidden sm:flex flex-col sm:flex-row gap-3">
                    <button onClick={() => fileInputRef.current?.click()} type="button" className="flex-1 bg-teal-500 text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:bg-teal-600 transition-colors flex items-center justify-center gap-2">
                        <TxtFileIcon /> Nhập DS (.txt)
                    </button>
                    <button onClick={handleExport} type="button" className="flex-1 bg-gray-500 text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:bg-gray-600 transition-colors flex items-center justify-center gap-2">
                        <ExportIcon /> Xuất DS (.txt)
                    </button>
                    <input type="file" ref={fileInputRef} onChange={handleFileImport} className="hidden" accept=".txt, text/plain" />
                </div>
            </div>
             <Modal isOpen={modalInfo.isOpen} onClose={() => setModalInfo({isOpen: false, title: '', message: ''})}>
                <h3 className="text-xl font-semibold mb-4">{modalInfo.title}</h3>
                <p>{modalInfo.message}</p>
                <div className="flex justify-end mt-6">
                    <button type="button" onClick={() => setModalInfo({isOpen: false, title: '', message: ''})} className="py-2 px-5 rounded-lg bg-blue-500 text-white hover:bg-blue-600">OK</button>
                </div>
            </Modal>
        </>
    );
};

export default AddStudentPanel;
