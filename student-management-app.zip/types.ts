
export interface Student {
  id: string;
  name: string;
  attendance: string[];
  paymentStatus: 'paid' | 'unpaid';
}

export interface ClosingHistoryRecord {
  id: string;
  startDate: string;
  endDate: string;
  totalSessions: number;
  totalTuition: number;
  closedAt: string;
}

export interface ClassData {
  id: string;
  name: string;
  tuitionFee: number;
  students: Student[];
  closingHistory: ClosingHistoryRecord[];
}
